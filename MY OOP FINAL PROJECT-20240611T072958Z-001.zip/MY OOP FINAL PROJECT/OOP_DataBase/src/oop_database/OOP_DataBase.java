/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oop_database;

/**
 *
 * @author Acer
 */
public class OOP_DataBase {

    static OPTION Gui;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (Gui == null) {
            Gui = new OPTION ();
            Gui.setVisible(true);
        }

    }

}
